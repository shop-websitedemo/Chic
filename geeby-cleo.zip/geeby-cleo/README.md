# geeby Cleo — Women's Boutique, Nashville TN

Chic boutique storefront built with **React + Vite + TypeScript + Tailwind CSS + Framer Motion**.

## Run it

```bash
npm install
npm run dev
```

Then open http://localhost:5173

## Build for production

```bash
npm run build      # outputs to dist/
npm run preview    # preview the production build
```

## Design tokens

| Token       | Value     | Usage                        |
|-------------|-----------|------------------------------|
| Cream       | `#FFFEF9` | Warm white background        |
| Ink         | `#0A0A0A` | Near-black primary / footer  |
| Clay        | `#C4622D` | Terracotta accent / CTAs     |
| Sand        | `#E8DCC8` | Warm sand secondary / bands  |

- Hero headings: Bebas Neue (condensed editorial sans)
- Body & product names: Inter; prices use `font-tabular` (tabular numerals)
- Hero image: slow 8s Ken Burns zoom
- Product cards: hover reveals a second photo, "Add to Bag" slides up
- Mobile: hamburger nav, swipeable product rows, stacked category blocks, sticky cart button

## Structure

```
src/
  data/products.ts        # products, brands, looks, reviews, IG photos
  components/
    Navbar, Hero, NewArrivals, ProductCard, Categories, Brands,
    Lookbook, Bestsellers, About, Reviews, Newsletter,
    InstagramRow, Footer, CartDrawer, StickyCart, Icons
  App.tsx                 # cart + wishlist state, section composition
```

Product and editorial photography are Unsplash stand-ins — swap the URLs in
`src/data/products.ts` (and the Hero/Categories/About components) for real
boutique photography when ready.
