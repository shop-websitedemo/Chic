export interface Product {
  id: string
  name: string
  brand: string
  price: number
  img: string
  imgAlt: string
}

export const newArrivals: Product[] = [
  {
    id: 'na-1',
    name: 'Silk Bias Slip Dress',
    brand: 'Vince',
    price: 248,
    img: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=800&q=80&auto=format&fit=crop',
    imgAlt: 'https://images.unsplash.com/photo-1539008835657-9e8e9680c956?w=800&q=80&auto=format&fit=crop',
  },
  {
    id: 'na-2',
    name: 'Puff Sleeve Blouse',
    brand: 'Velvet',
    price: 148,
    img: 'https://images.unsplash.com/photo-1554412933-514a83d2f3c8?w=800&q=80&auto=format&fit=crop',
    imgAlt: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=800&q=80&auto=format&fit=crop',
  },
  {
    id: 'na-3',
    name: 'Crochet Midi Dress',
    brand: 'Ulla Johnson',
    price: 325,
    img: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=800&q=80&auto=format&fit=crop',
    imgAlt: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=800&q=80&auto=format&fit=crop',
  },
  {
    id: 'na-4',
    name: 'Tailored Wide-Leg Trouser',
    brand: 'Veronica Beard',
    price: 198,
    img: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=800&q=80&auto=format&fit=crop',
    imgAlt: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=800&q=80&auto=format&fit=crop',
  },
  {
    id: 'na-5',
    name: 'Utility Field Jacket',
    brand: 'Rails',
    price: 178,
    img: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=800&q=80&auto=format&fit=crop',
    imgAlt: 'https://images.unsplash.com/photo-1544022613-e87ca75a784a?w=800&q=80&auto=format&fit=crop',
  },
]

export const bestsellers: Product[] = [
  {
    id: 'bs-1',
    name: 'The Perfect Tee',
    brand: 'Rails',
    price: 68,
    img: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800&q=80&auto=format&fit=crop',
    imgAlt: 'https://images.unsplash.com/photo-1485968579580-b6d095142e6e?w=800&q=80&auto=format&fit=crop',
  },
  {
    id: 'bs-2',
    name: 'Floral Wrap Dress',
    brand: 'Free People',
    price: 128,
    img: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=800&q=80&auto=format&fit=crop',
    imgAlt: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=800&q=80&auto=format&fit=crop',
  },
  {
    id: 'bs-3',
    name: 'Cashmere Cardigan',
    brand: 'Vince',
    price: 298,
    img: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=800&q=80&auto=format&fit=crop',
    imgAlt: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=800&q=80&auto=format&fit=crop',
  },
  {
    id: 'bs-4',
    name: 'Denim Column Skirt',
    brand: 'Veronica Beard',
    price: 158,
    img: 'https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?w=800&q=80&auto=format&fit=crop',
    imgAlt: 'https://images.unsplash.com/photo-1495385794356-15371f348c31?w=800&q=80&auto=format&fit=crop',
  },
]

export const brands = ['Vince', 'Velvet', 'Ulla Johnson', 'Free People', 'Veronica Beard', 'Rails']

export interface Look {
  id: string
  img: string
  title: string
  description: string
  pieces: string[]
}

export const looks: Look[] = [
  {
    id: 'look-1',
    img: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=1000&q=80&auto=format&fit=crop',
    title: 'Look 01 — Golden Hour',
    description:
      'A silk slip layered under an open-weave cardigan, finished with a suede mule. Made for long dinners on the patio at Margot and slow Sunday mornings on 12th Ave.',
    pieces: ['Silk Bias Slip Dress', 'Cashmere Cardigan', 'Suede Mule'],
  },
  {
    id: 'look-2',
    img: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=1000&q=80&auto=format&fit=crop',
    title: 'Look 02 — Gallery Weekend',
    description:
      'Crisp cotton poplin with a full skirt and sculptural gold. Sharp enough for the Frist, easy enough to wear straight through to drinks in Germantown.',
    pieces: ['Puff Sleeve Blouse', 'Denim Column Skirt', 'Sculptural Cuff'],
  },
  {
    id: 'look-3',
    img: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=1000&q=80&auto=format&fit=crop',
    title: 'Look 03 — Layered & Easy',
    description:
      'The field jacket thrown over wide-leg tailoring — the Nashville uniform for weather that cannot make up its mind. Add a vintage band tee when it warms up.',
    pieces: ['Utility Field Jacket', 'Wide-Leg Trouser', 'Vintage Wash Tee'],
  },
]

export const instagramPhotos = [
  'https://images.unsplash.com/photo-1485968579580-b6d095142e6e?w=600&q=80&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1495385794356-15371f348c31?w=600&q=80&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?w=600&q=80&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=600&q=80&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=600&q=80&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=600&q=80&auto=format&fit=crop',
]

export const reviews = [
  {
    name: 'Maren K.',
    location: '12 South',
    quote:
      'The only boutique in Nashville where I walk in for one thing and leave with a whole new wardrobe. The styling advice is always spot on.',
  },
  {
    name: 'Jasmine T.',
    location: 'East Nashville',
    quote:
      'Every piece feels like it was picked just for me. My Ulla Johnson dress gets compliments every single time I wear it.',
  },
  {
    name: 'Colleen R.',
    location: 'Germantown',
    quote:
      'Warm, unpretentious, and beautifully curated. geeby Cleo is my first stop before every event — and most ordinary Tuesdays, too.',
  },
]
