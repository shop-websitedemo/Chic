import { useState } from 'react'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import NewArrivals from './components/NewArrivals'
import Categories from './components/Categories'
import Brands from './components/Brands'
import Lookbook from './components/Lookbook'
import Bestsellers from './components/Bestsellers'
import About from './components/About'
import Reviews from './components/Reviews'
import Newsletter from './components/Newsletter'
import InstagramRow from './components/InstagramRow'
import Footer from './components/Footer'
import CartDrawer, { type CartItem } from './components/CartDrawer'
import StickyCart from './components/StickyCart'
import { newArrivals, bestsellers, type Product } from './data/products'

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([])
  const [wishlist, setWishlist] = useState<Set<string>>(new Set())
  const [cartOpen, setCartOpen] = useState(false)

  const addToCart = (p: Product) =>
    setCart((prev) => {
      const existing = prev.find((i) => i.product.id === p.id)
      if (existing) {
        return prev.map((i) => (i.product.id === p.id ? { ...i, qty: i.qty + 1 } : i))
      }
      return [...prev, { product: p, qty: 1 }]
    })

  const updateQty = (id: string, qty: number) => {
    if (qty <= 0) return removeItem(id)
    setCart((prev) => prev.map((i) => (i.product.id === id ? { ...i, qty } : i)))
  }

  const removeItem = (id: string) => setCart((prev) => prev.filter((i) => i.product.id !== id))

  const toggleWish = (id: string) =>
    setWishlist((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })

  const cartCount = cart.reduce((sum, i) => sum + i.qty, 0)

  return (
    <div className="bg-cream text-ink min-h-screen">
      <Navbar cartCount={cartCount} wishCount={wishlist.size} onCartOpen={() => setCartOpen(true)} />
      <main>
        <Hero />
        <NewArrivals products={newArrivals} onAdd={addToCart} wishlist={wishlist} onToggleWish={toggleWish} />
        <Categories />
        <Brands />
        <Lookbook />
        <Bestsellers products={bestsellers} onAdd={addToCart} wishlist={wishlist} onToggleWish={toggleWish} />
        <About />
        <Reviews />
        <Newsletter />
        <InstagramRow />
      </main>
      <Footer />
      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cart}
        onUpdateQty={updateQty}
        onRemove={removeItem}
      />
      <StickyCart count={cartCount} onOpen={() => setCartOpen(true)} />
    </div>
  )
}
