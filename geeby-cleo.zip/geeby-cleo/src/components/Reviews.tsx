import { motion } from 'framer-motion'
import { reviews } from '../data/products'
import { StarIcon } from './Icons'

export default function Reviews() {
  return (
    <section className="py-20 lg:py-28 border-t border-ink/10">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="text-center mb-14">
          <p className="text-[11px] font-medium uppercase tracking-mega text-clay mb-3">Word of Mouth</p>
          <h2 className="font-display text-5xl lg:text-6xl tracking-[0.03em]">Loved in Nashville</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {reviews.map((r, i) => (
            <motion.figure
              key={r.name}
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, delay: i * 0.12 }}
              className="bg-sand/50 p-8 flex flex-col"
            >
              <div className="flex gap-1 text-clay mb-5">
                {Array.from({ length: 5 }).map((_, s) => (
                  <StarIcon key={s} />
                ))}
              </div>
              <blockquote className="text-ink/80 leading-relaxed flex-1">&ldquo;{r.quote}&rdquo;</blockquote>
              <figcaption className="mt-6 pt-5 border-t border-ink/10">
                <p className="text-sm font-semibold">{r.name}</p>
                <p className="text-xs uppercase tracking-[0.18em] text-ink/50 mt-1">{r.location}</p>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  )
}
