import { motion } from 'framer-motion'
import { ArrowRightIcon } from './Icons'

const categories = [
  {
    title: 'Tops & Blouses',
    img: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=1200&q=80&auto=format&fit=crop',
  },
  {
    title: 'Dresses & Skirts',
    img: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=1200&q=80&auto=format&fit=crop',
  },
  {
    title: 'Outerwear & Layers',
    img: 'https://images.unsplash.com/photo-1544022613-e87ca75a784a?w=1200&q=80&auto=format&fit=crop',
  },
]

export default function Categories() {
  return (
    <section id="shop" className="flex flex-col md:flex-row">
      {categories.map((c, i) => (
        <motion.a
          key={c.title}
          href="#new-arrivals"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7, delay: i * 0.12 }}
          className="group relative h-[70vh] md:h-screen md:min-h-[640px] overflow-hidden flex-1"
        >
          <img
            src={c.img}
            alt={c.title}
            loading="lazy"
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/60 via-transparent to-transparent transition-opacity duration-500 group-hover:opacity-70" />
          <div className="absolute inset-x-6 bottom-6 lg:inset-x-10 lg:bottom-10">
            <div className="bg-cream p-6 lg:p-8 flex items-center justify-between gap-4 transition-colors duration-500 group-hover:bg-ink group-hover:text-cream">
              <h3 className="font-display text-2xl lg:text-3xl tracking-[0.04em]">{c.title}</h3>
              <span className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-mega">
                Shop
                <ArrowRightIcon className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </span>
            </div>
          </div>
        </motion.a>
      ))}
    </section>
  )
}
