import { motion, AnimatePresence } from 'framer-motion'
import { BagIcon } from './Icons'

interface StickyCartProps {
  count: number
  onOpen: () => void
}

export default function StickyCart({ count, onOpen }: StickyCartProps) {
  return (
    <AnimatePresence>
      {count > 0 && (
        <motion.button
          initial={{ opacity: 0, scale: 0.8, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 16 }}
          onClick={onOpen}
          aria-label="Open cart"
          className="md:hidden fixed bottom-5 right-5 z-50 bg-ink text-cream rounded-full p-4 shadow-xl shadow-ink/30"
        >
          <BagIcon />
          <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-clay text-[10px] font-semibold flex items-center justify-center">
            {count}
          </span>
        </motion.button>
      )}
    </AnimatePresence>
  )
}
