import { motion } from 'framer-motion'
import { MapPinIcon } from './Icons'

export default function About() {
  return (
    <section id="about" className="py-20 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8 grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.7 }}
        >
          <p className="text-[11px] font-medium uppercase tracking-mega text-clay mb-3">Our Story</p>
          <h2 className="font-display text-5xl lg:text-6xl tracking-[0.03em] mb-6">A Boutique Built on Intuition</h2>
          <p className="text-ink/70 leading-relaxed mb-5">
            geeby Cleo opened its doors on 12th Avenue South with a simple belief: getting dressed should feel
            like the easiest, most joyful part of your day. We hunt down the pieces you will reach for again and
            again — silk that drapes just right, denim that fits like it was made for you, layers that move with
            Nashville's ever-changing weather.
          </p>
          <p className="text-ink/70 leading-relaxed mb-10">
            Every brand on our racks is chosen by hand, in small batches, with an eye for quality over quantity.
            Come say hello — the fitting rooms are warm and the coffee is always on.
          </p>
          <div className="flex items-start gap-4 border-t border-ink/10 pt-8">
            <MapPinIcon className="w-5 h-5 text-clay mt-0.5 flex-none" />
            <div>
              <p className="font-medium text-sm">2907 12th Ave S, Nashville, TN 37204</p>
              <p className="text-sm text-ink/60 mt-1">Open Mon–Sat 10–6, Sun 12–5</p>
            </div>
          </div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.7, delay: 0.15 }}
          className="overflow-hidden"
        >
          <img
            src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1400&q=80&auto=format&fit=crop"
            alt="Inside the geeby Cleo boutique"
            loading="lazy"
            className="w-full h-[60vh] lg:h-[75vh] object-cover"
          />
        </motion.div>
      </div>
    </section>
  )
}
