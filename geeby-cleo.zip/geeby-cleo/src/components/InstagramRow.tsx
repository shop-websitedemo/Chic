import { motion } from 'framer-motion'
import { instagramPhotos } from '../data/products'
import { InstagramIcon } from './Icons'

export default function InstagramRow() {
  return (
    <section className="py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="text-center mb-10">
          <p className="text-[11px] font-medium uppercase tracking-mega text-ink/50 mb-3">Follow Along</p>
          <a href="#top" className="inline-flex items-center gap-3 font-display text-4xl lg:text-5xl tracking-[0.05em] hover:text-clay transition-colors">
            <InstagramIcon className="w-7 h-7" />
            @geebycleo
          </a>
        </div>
        <div className="grid grid-cols-3 md:grid-cols-6 gap-2 lg:gap-3">
          {instagramPhotos.map((src, i) => (
            <motion.a
              key={src}
              href="#top"
              initial={{ opacity: 0, scale: 0.96 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.06 }}
              className="group relative aspect-square overflow-hidden bg-sand/50"
            >
              <img
                src={src}
                alt="geeby Cleo on Instagram"
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-clay/0 group-hover:bg-clay/30 transition-colors duration-300" />
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  )
}
