import { motion } from 'framer-motion'
import type { Product } from '../data/products'
import { HeartIcon } from './Icons'

interface ProductCardProps {
  product: Product
  onAdd: (p: Product) => void
  wished: boolean
  onToggleWish: (id: string) => void
  badge?: string
}

export default function ProductCard({ product, onAdd, wished, onToggleWish, badge }: ProductCardProps) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.55 }}
      className="group relative flex-none w-[68vw] sm:w-[42vw] lg:w-[23%] snap-start"
    >
      <div className="relative aspect-[3/4] overflow-hidden bg-sand/50">
        <img
          src={product.img}
          alt={product.name}
          loading="lazy"
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <img
          src={product.imgAlt}
          alt=""
          loading="lazy"
          className="absolute inset-0 w-full h-full object-cover opacity-0 transition-opacity duration-700 group-hover:opacity-100"
        />

        {badge && (
          <span className="absolute top-3 left-3 bg-clay text-cream text-[10px] font-semibold uppercase tracking-[0.18em] px-3 py-1.5">
            {badge}
          </span>
        )}

        <button
          aria-label="Add to wishlist"
          onClick={() => onToggleWish(product.id)}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-sm transition-colors ${
            wished ? 'bg-clay text-cream' : 'bg-cream/80 text-ink hover:bg-clay hover:text-cream'
          }`}
        >
          <HeartIcon className="w-4 h-4" filled={wished} />
        </button>

        <button
          onClick={() => onAdd(product)}
          className="absolute inset-x-0 bottom-0 translate-y-full group-hover:translate-y-0 transition-transform duration-300 bg-ink/90 text-cream text-[11px] font-semibold uppercase tracking-mega py-3.5 hover:bg-clay"
        >
          Add to Bag
        </button>
      </div>

      <div className="pt-4 flex items-start justify-between gap-3">
        <div>
          <p className="text-[10px] uppercase tracking-[0.2em] text-ink/50 mb-1">{product.brand}</p>
          <h3 className="text-sm font-medium text-ink">{product.name}</h3>
        </div>
        <p className="font-tabular text-sm text-ink pt-4">${product.price}</p>
      </div>
    </motion.article>
  )
}
