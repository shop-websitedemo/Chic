import { useRef } from 'react'
import type { Product } from '../data/products'
import ProductCard from './ProductCard'
import { ChevronLeftIcon, ChevronRightIcon } from './Icons'

interface NewArrivalsProps {
  products: Product[]
  onAdd: (p: Product) => void
  wishlist: Set<string>
  onToggleWish: (id: string) => void
}

export default function NewArrivals({ products, onAdd, wishlist, onToggleWish }: NewArrivalsProps) {
  const trackRef = useRef<HTMLDivElement>(null)

  const scroll = (dir: 1 | -1) => {
    trackRef.current?.scrollBy({ left: dir * trackRef.current.clientWidth * 0.8, behavior: 'smooth' })
  }

  return (
    <section id="new-arrivals" className="py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="text-[11px] font-medium uppercase tracking-mega text-clay mb-3">Just Landed</p>
            <h2 className="font-display text-5xl lg:text-6xl tracking-[0.03em]">New Arrivals</h2>
          </div>
          <div className="hidden sm:flex gap-2">
            <button
              onClick={() => scroll(-1)}
              aria-label="Scroll left"
              className="p-3 border border-ink/15 hover:bg-ink hover:text-cream hover:border-ink transition-colors"
            >
              <ChevronLeftIcon />
            </button>
            <button
              onClick={() => scroll(1)}
              aria-label="Scroll right"
              className="p-3 border border-ink/15 hover:bg-ink hover:text-cream hover:border-ink transition-colors"
            >
              <ChevronRightIcon />
            </button>
          </div>
        </div>
      </div>

      <div
        ref={trackRef}
        className="no-scrollbar flex gap-5 lg:gap-6 overflow-x-auto snap-x snap-mandatory px-5 lg:px-[max(2rem,calc((100vw-80rem)/2+2rem))] pb-2"
      >
        {products.map((p) => (
          <ProductCard
            key={p.id}
            product={p}
            onAdd={onAdd}
            wished={wishlist.has(p.id)}
            onToggleWish={onToggleWish}
          />
        ))}
      </div>
    </section>
  )
}
