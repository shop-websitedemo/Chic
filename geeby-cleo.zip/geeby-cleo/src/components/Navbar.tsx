import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { SearchIcon, HeartIcon, BagIcon, MenuIcon, CloseIcon } from './Icons'

interface NavbarProps {
  cartCount: number
  wishCount: number
  onCartOpen: () => void
}

const links = [
  { label: 'Shop', href: '#shop' },
  { label: 'New Arrivals', href: '#new-arrivals' },
  { label: 'Brands', href: '#brands' },
  { label: 'Sale', href: '#sale' },
]

export default function Navbar({ cartCount, wishCount, onCartOpen }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const light = !scrolled && !menuOpen

  return (
    <>
      <header
        className={`fixed top-0 inset-x-0 z-50 transition-colors duration-300 ${
          scrolled || menuOpen ? 'bg-cream/90 backdrop-blur-md border-b border-ink/10' : 'bg-transparent'
        } ${light ? 'text-cream' : 'text-ink'}`}
      >
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="relative flex h-16 lg:h-20 items-center justify-between">
            {/* Left links (desktop) */}
            <nav className="hidden lg:flex items-center gap-8 flex-1">
              {links.map((l) => (
                <a
                  key={l.label}
                  href={l.href}
                  className="text-[11px] font-medium uppercase tracking-mega hover:text-clay transition-colors"
                >
                  {l.label}
                </a>
              ))}
            </nav>

            {/* Hamburger (mobile) */}
            <button
              className="lg:hidden p-2 -ml-2"
              onClick={() => setMenuOpen((v) => !v)}
              aria-label="Toggle menu"
            >
              {menuOpen ? <CloseIcon /> : <MenuIcon />}
            </button>

            {/* Center logo */}
            <a
              href="#top"
              className="absolute left-1/2 -translate-x-1/2 font-display text-2xl lg:text-3xl tracking-[0.12em] whitespace-nowrap"
            >
              geeby&nbsp;Cleo
            </a>

            {/* Right icons */}
            <div className="flex items-center justify-end gap-1 lg:gap-3 flex-1">
              <button aria-label="Search" className="p-2 hover:text-clay transition-colors hidden sm:block">
                <SearchIcon />
              </button>
              <button aria-label="Wishlist" className="p-2 hover:text-clay transition-colors relative">
                <HeartIcon />
                {wishCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-clay text-cream text-[9px] font-semibold flex items-center justify-center">
                    {wishCount}
                  </span>
                )}
              </button>
              <button aria-label="Cart" onClick={onCartOpen} className="p-2 hover:text-clay transition-colors relative">
                <BagIcon />
                {cartCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-clay text-cream text-[9px] font-semibold flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.nav
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="fixed top-16 inset-x-0 z-40 bg-cream border-b border-ink/10 lg:hidden"
          >
            <div className="px-6 py-6 flex flex-col gap-5">
              {links.map((l) => (
                <a
                  key={l.label}
                  href={l.href}
                  onClick={() => setMenuOpen(false)}
                  className="font-display text-3xl tracking-wide text-ink hover:text-clay transition-colors"
                >
                  {l.label}
                </a>
              ))}
              <div className="pt-4 border-t border-ink/10 flex items-center gap-4 text-ink">
                <button aria-label="Search" className="p-2">
                  <SearchIcon />
                </button>
                <span className="text-xs uppercase tracking-mega text-ink/50">Search the boutique</span>
              </div>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </>
  )
}
