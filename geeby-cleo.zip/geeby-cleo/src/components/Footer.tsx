import { MapPinIcon, InstagramIcon, FacebookIcon } from './Icons'

const columns = [
  {
    title: 'Shop',
    links: ['New Arrivals', 'Tops & Blouses', 'Dresses & Skirts', 'Outerwear & Layers', 'Sale'],
  },
  {
    title: 'Help',
    links: ['Shipping & Returns', 'Size Guide', 'Gift Cards', 'Contact Us'],
  },
  {
    title: 'The Boutique',
    links: ['Our Story', 'Lookbook', 'Reviews', 'Journal'],
  },
]

export default function Footer() {
  return (
    <footer className="bg-ink text-cream/70">
      <div className="mx-auto max-w-7xl px-5 lg:px-8 py-16 lg:py-24">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <p className="font-display text-4xl tracking-[0.1em] text-cream mb-5">geeby Cleo</p>
            <p className="text-sm leading-relaxed max-w-sm mb-8">
              A women's clothing boutique in the heart of 12 South, Nashville. Curated style,
              effortlessly yours — in store and online.
            </p>
            <div className="flex items-center gap-3 text-sm">
              <MapPinIcon className="w-4 h-4 text-clay flex-none" />
              2907 12th Ave S, Nashville, TN 37204
            </div>
            <div className="flex gap-3 mt-8">
              <a href="#top" aria-label="Instagram" className="p-3 border border-cream/20 hover:border-clay hover:text-clay transition-colors">
                <InstagramIcon className="w-4 h-4" />
              </a>
              <a href="#top" aria-label="Facebook" className="p-3 border border-cream/20 hover:border-clay hover:text-clay transition-colors">
                <FacebookIcon className="w-4 h-4" />
              </a>
            </div>
          </div>
          {columns.map((col) => (
            <div key={col.title} className="lg:col-span-2">
              <p className="text-[11px] font-semibold uppercase tracking-mega text-cream mb-6">{col.title}</p>
              <ul className="space-y-3">
                {col.links.map((l) => (
                  <li key={l}>
                    <a href="#top" className="text-sm hover:text-clay transition-colors">
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-16 pt-8 border-t border-cream/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <p>&copy; {new Date().getFullYear()} geeby Cleo, Nashville TN. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#top" className="hover:text-clay transition-colors">Privacy</a>
            <a href="#top" className="hover:text-clay transition-colors">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  )
}
