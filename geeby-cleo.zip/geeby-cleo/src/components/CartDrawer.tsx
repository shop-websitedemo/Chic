import { AnimatePresence, motion } from 'framer-motion'
import type { Product } from '../data/products'
import { CloseIcon } from './Icons'

export interface CartItem {
  product: Product
  qty: number
}

interface CartDrawerProps {
  open: boolean
  onClose: () => void
  items: CartItem[]
  onUpdateQty: (id: string, qty: number) => void
  onRemove: (id: string) => void
}

export default function CartDrawer({ open, onClose, items, onUpdateQty, onRemove }: CartDrawerProps) {
  const subtotal = items.reduce((sum, i) => sum + i.product.price * i.qty, 0)

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-[60] bg-ink/50 backdrop-blur-sm"
          />
          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'tween', duration: 0.3, ease: 'easeOut' }}
            className="fixed top-0 right-0 z-[70] h-full w-full max-w-md bg-cream flex flex-col"
          >
            <div className="flex items-center justify-between px-6 py-5 border-b border-ink/10">
              <h2 className="font-display text-3xl tracking-[0.05em]">Your Bag</h2>
              <button onClick={onClose} aria-label="Close cart" className="p-2 hover:text-clay transition-colors">
                <CloseIcon />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
              {items.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center gap-4">
                  <p className="font-display text-3xl tracking-wide text-ink/60">Your bag is empty</p>
                  <button
                    onClick={onClose}
                    className="text-xs font-semibold uppercase tracking-mega text-clay border-b border-clay pb-1"
                  >
                    Keep Browsing
                  </button>
                </div>
              ) : (
                items.map(({ product, qty }) => (
                  <div key={product.id} className="flex gap-4">
                    <img src={product.img} alt={product.name} className="w-20 h-24 object-cover bg-sand/50" />
                    <div className="flex-1">
                      <p className="text-[10px] uppercase tracking-[0.18em] text-ink/50">{product.brand}</p>
                      <p className="text-sm font-medium">{product.name}</p>
                      <p className="font-tabular text-sm mt-1">${product.price}</p>
                      <div className="flex items-center gap-3 mt-3">
                        <button
                          onClick={() => onUpdateQty(product.id, qty - 1)}
                          className="w-7 h-7 border border-ink/15 hover:border-ink transition-colors text-sm"
                        >
                          −
                        </button>
                        <span className="font-tabular text-sm w-4 text-center">{qty}</span>
                        <button
                          onClick={() => onUpdateQty(product.id, qty + 1)}
                          className="w-7 h-7 border border-ink/15 hover:border-ink transition-colors text-sm"
                        >
                          +
                        </button>
                        <button
                          onClick={() => onRemove(product.id)}
                          className="ml-auto text-xs text-ink/50 hover:text-clay underline underline-offset-2 transition-colors"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {items.length > 0 && (
              <div className="px-6 py-6 border-t border-ink/10">
                <div className="flex justify-between mb-5">
                  <span className="text-sm text-ink/60">Subtotal</span>
                  <span className="font-tabular font-semibold">${subtotal}</span>
                </div>
                <button className="w-full bg-ink text-cream py-4 text-xs font-semibold uppercase tracking-mega hover:bg-clay transition-colors">
                  Checkout
                </button>
                <p className="text-center text-xs text-ink/50 mt-3">Free shipping on orders over $150</p>
              </div>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  )
}
