import { motion } from 'framer-motion'
import { brands } from '../data/products'

export default function Brands() {
  return (
    <section id="brands" className="py-20 lg:py-28 border-y border-ink/10">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center text-[11px] font-medium uppercase tracking-mega text-ink/50 mb-12"
        >
          Curated Brands We Love
        </motion.p>
        <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-6 lg:gap-x-16">
          {brands.map((b, i) => (
            <motion.span
              key={b}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.07 }}
              className="font-display text-3xl lg:text-5xl tracking-[0.05em] text-ink/70 hover:text-clay transition-colors duration-300 cursor-default"
            >
              {b}
            </motion.span>
          ))}
        </div>
      </div>
    </section>
  )
}
