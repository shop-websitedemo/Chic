import type { Product } from '../data/products'
import ProductCard from './ProductCard'

interface BestsellersProps {
  products: Product[]
  onAdd: (p: Product) => void
  wishlist: Set<string>
  onToggleWish: (id: string) => void
}

export default function Bestsellers({ products, onAdd, wishlist, onToggleWish }: BestsellersProps) {
  return (
    <section id="sale" className="py-20 lg:py-28 bg-sand/40">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="flex items-end justify-between mb-10 lg:mb-14">
          <div>
            <p className="text-[11px] font-medium uppercase tracking-mega text-clay mb-3">
              Community Favorites — up to 40% off select styles
            </p>
            <h2 className="font-display text-5xl lg:text-6xl tracking-[0.03em]">Bestsellers</h2>
          </div>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 lg:gap-6">
          {products.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              onAdd={onAdd}
              wished={wishlist.has(p.id)}
              onToggleWish={onToggleWish}
              badge="Bestseller"
            />
          ))}
        </div>
      </div>
    </section>
  )
}
