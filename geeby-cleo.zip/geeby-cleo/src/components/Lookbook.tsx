import { motion } from 'framer-motion'
import { looks } from '../data/products'
import { ArrowRightIcon } from './Icons'

export default function Lookbook() {
  return (
    <section id="lookbook" className="py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mb-14 lg:mb-20">
          <p className="text-[11px] font-medium uppercase tracking-mega text-clay mb-3">The Lookbook</p>
          <h2 className="font-display text-5xl lg:text-6xl tracking-[0.03em]">Styled by geeby Cleo</h2>
        </div>

        <div className="flex flex-col gap-20 lg:gap-28">
          {looks.map((look, i) => (
            <div
              key={look.id}
              className={`flex flex-col gap-8 lg:gap-16 lg:items-center ${
                i % 2 === 1 ? 'lg:flex-row-reverse' : 'lg:flex-row'
              }`}
            >
              <motion.div
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-100px' }}
                transition={{ duration: 0.7 }}
                className="lg:w-1/2 overflow-hidden"
              >
                <img
                  src={look.img}
                  alt={look.title}
                  loading="lazy"
                  className="w-full h-[60vh] lg:h-[75vh] object-cover"
                />
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-100px' }}
                transition={{ duration: 0.7, delay: 0.15 }}
                className="lg:w-1/2 lg:px-8"
              >
                <h3 className="font-display text-4xl lg:text-5xl tracking-[0.04em] mb-5">{look.title}</h3>
                <p className="text-ink/70 leading-relaxed max-w-md mb-8">{look.description}</p>
                <ul className="mb-10 space-y-2">
                  {look.pieces.map((p) => (
                    <li key={p} className="flex items-center gap-3 text-sm text-ink/80">
                      <span className="w-6 h-px bg-clay" />
                      {p}
                    </li>
                  ))}
                </ul>
                <a
                  href="#new-arrivals"
                  className="group inline-flex items-center gap-3 text-xs font-semibold uppercase tracking-mega text-clay border-b border-clay pb-2 hover:text-ink hover:border-ink transition-colors"
                >
                  Shop This Look
                  <ArrowRightIcon className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
                </a>
              </motion.div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
