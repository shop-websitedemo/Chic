import { motion } from 'framer-motion'
import { ArrowRightIcon } from './Icons'

export default function Hero() {
  return (
    <section id="top" className="relative h-[100svh] min-h-[560px] overflow-hidden bg-ink">
      {/* Ken Burns campaign image */}
      <img
        src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=2000&q=80&auto=format&fit=crop"
        alt="geeby Cleo fall campaign"
        className="kenburns absolute inset-0 w-full h-full object-cover object-[center_20%] opacity-90"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/20 to-ink/10" />

      {/* Editorial overlay */}
      <div className="relative z-10 h-full mx-auto max-w-7xl px-5 lg:px-8 flex flex-col justify-end pb-24 lg:pb-32">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="text-cream/80 text-[11px] lg:text-xs font-medium uppercase tracking-mega mb-4"
        >
          Fall 2026 — The Nashville Edit
        </motion.p>
        <motion.h1
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.35 }}
          className="font-display text-cream text-[15vw] sm:text-7xl lg:text-8xl xl:text-9xl leading-[0.95] tracking-[0.02em] max-w-4xl"
        >
          Curated Style,
          <br />
          Effortlessly Yours
        </motion.h1>
        <motion.a
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.55 }}
          href="#new-arrivals"
          className="group mt-8 inline-flex w-fit items-center gap-3 bg-clay text-cream px-8 py-4 text-xs font-semibold uppercase tracking-mega hover:bg-cream hover:text-ink transition-colors duration-300"
        >
          Shop New Arrivals
          <ArrowRightIcon className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
        </motion.a>
      </div>

      {/* Scroll hint */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 1 }}
        className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 hidden lg:block"
      >
        <div className="w-px h-12 bg-cream/40 overflow-hidden">
          <motion.div
            className="w-full h-1/2 bg-cream"
            animate={{ y: ['-100%', '200%'] }}
            transition={{ repeat: Infinity, duration: 1.8, ease: 'easeInOut' }}
          />
        </div>
      </motion.div>
    </section>
  )
}
