import { useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowRightIcon } from './Icons'

export default function Newsletter() {
  const [email, setEmail] = useState('')
  const [done, setDone] = useState(false)

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email.trim()) setDone(true)
  }

  return (
    <section className="bg-sand py-20 lg:py-28">
      <div className="mx-auto max-w-2xl px-5 text-center">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="font-display text-5xl lg:text-6xl tracking-[0.03em] mb-4">Be the First to Know</h2>
          <p className="text-ink/70 mb-10">
            New arrivals, restocks, and Nashville-only events — straight to your inbox, never more than twice a month.
          </p>
          {done ? (
            <p className="text-sm font-semibold uppercase tracking-mega text-clay">
              Welcome to the list — see you soon.
            </p>
          ) : (
            <form onSubmit={submit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email address"
                className="flex-1 bg-cream border border-ink/15 px-5 py-4 text-sm outline-none focus:border-clay transition-colors placeholder:text-ink/40"
              />
              <button
                type="submit"
                className="group inline-flex items-center justify-center gap-2 bg-ink text-cream px-7 py-4 text-xs font-semibold uppercase tracking-mega hover:bg-clay transition-colors"
              >
                Sign Up
                <ArrowRightIcon className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </button>
            </form>
          )}
        </motion.div>
      </div>
    </section>
  )
}
